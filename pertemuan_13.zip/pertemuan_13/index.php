<html>
  <head>
    <link rel="stylesheet" href="style.css">
  </head>
  <body>
    <table width="700" border="1">
      <tr>
        <td colspan="2" align="center"><h1>Sistem Informasi Perpustakaan</h1> <br><></td>
      </tr>
      <tr class="tr2">
        <td width = "200">
      <ul>
        <li><a href="anggota.php">Anggota</a></li>
        <li><a href="buku.php">Buku</a></li>
        <li><a href="pinjam.php">Pinjam</a></li>
      <ul>

      </td>
        <td width="500">Selamat Datang Di Sistem Perpustakaan</td>
      </tr>
      <tr>
        <td colspan="2" align="center">Kelompok 1</td>
      </tr>
    </table>
  </body>
</html>
